#!/bin/bash

echo "Simple calculator"
echo "Insert 2 numbers and 1 operand , get your result"

# Getting first number and checking for its authenticity
echo "Enter first number:"
read A
if ! [[ $A =~ ^[+-]?[0-9]+$ ]]; then
	echo "$A is not a number"
	exit 1
fi

# Getting second number and checking for its authenticity

echo "Enter second number:"
read B
if ! [[ $B =~ ^[+-]?[0-9]+$ ]]; then
	echo "$B is not a number"
	exit 1
fi

echo "Enter operand:"
read operand
 
# Switch Case to perform
# calculator operations
echo -n "Result: "
case $operand in
	+)
		expr "$A" + "$B";;
	-)
		expr "$A" - "$B";;
	\*)
		expr "$A" \* "$B";;
	/)
		expr "$A" / "$B";;
esac

