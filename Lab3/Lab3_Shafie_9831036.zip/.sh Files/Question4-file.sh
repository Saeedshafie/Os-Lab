#!/bin/bash

read -p "Enter file name: " file
read -p "Enter starting line number: " a
read -p "Enter stopping line number: " b

sed -n "$a,$b p" $file


