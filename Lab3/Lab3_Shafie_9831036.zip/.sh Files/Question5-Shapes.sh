#!/bin/bash

function shape1(){
	row=5
	col=5
	for((i=1; i<=row; i++))
	do
		for((j=1; j<=i; j++))
	  	do
	    		echo -n "$i"
	  	done
		echo
	done

}
#shape1
function shape2(){
	for (( i=1;i<=6 ;i++))
	do
   		for (( j=6;j>=i;j-- ))
   		do
   			echo -n " "
   		done
   		for (( c=1;c<=i;c++ ))
   		do
   			echo -n " *"
   		done
		echo ""
	done
	for (( i=6;i>=1;i--))
	do
   		for (( j=i;j<=6;j++ ))
   		do
   			if [ $j -eq 6 ]
   			then
  				echo -n ""
   			fi
   			echo -n " "
  		done
   		for (( c=1;c<=i;c++ ))
   		do
   			echo -n " *"
   		done
		echo ""
	done
} 
#shape2

function shape3(){
	echo "|"
	echo "---"
	echo "|  |"
	echo "   ---"
	echo "|  |  |"
	echo "      ---"
	echo "|  |  |  |"
	echo "         ---"
	echo "|  |  |  |  |"
	echo "            ---"
}
#shape3
read -p "Enter a number between 1-3: " num
if [[ $num -eq 1 ]]; then
	shape1
elif [[ $num -eq 2 ]]; then
	shape2
elif [[ $num -eq 3 ]]; then
	shape3 
else 
	echo "Invalid Number"
	exit 1 
fi
