#!/bin/bash

read -p 'Username: ' uservar | tee data.txt
read -p 'Password: ' passvar | tee data.txt


