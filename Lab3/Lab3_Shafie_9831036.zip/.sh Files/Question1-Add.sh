#!/bin/bash

# Getting the input
if [[ $# -ne 2 ]]; then
	echo "Number of arguments must be 2"
	exit 1
fi

# Integer Only Condition check
# Could be Written by  a for loop also

if ! [[ $1 =~ ^[+-]?[0-9]+$ ]]; then
	echo "$1 is not a number"
	exit 1
elif ! [[ $2 =~ ^[+-]?[0-9]+$ ]]; then
	echo "$2 is not a number"
	exit 1
fi




sum=$(( $1 + $2 ))
echo "Sum of two arguments is : $sum"

# Comparing the numbers

if [[ $1 -gt $2 ]]; then
	echo "$1 is greater than $2"
elif [[ $2 -gt $1 ]]; then
	echo "$2 is greater than $1"
else
	echo "Two inputs have equal values"
fi
