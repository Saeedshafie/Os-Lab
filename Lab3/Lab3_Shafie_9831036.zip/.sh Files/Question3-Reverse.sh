#!/bin/bash

read -p "Enter a number: " number

#Reverse Process as we used to do it
<< comment 

while [ $temp -ne 0 ]
do
    reverse=$reverse$((temp%10))
    temp=$((temp/10))
done
comment



until [[ "$number" -eq -1 ]]; do
	# Reverse using the function
	echo "Reverse of $number is $(echo $number | rev)"
	
	# Calculatin sum of digits
	temp=$number
	sum=0
	while [ $number -gt 0 ]
	do
		mod=$((number % 10))    #split each digits
    		sum=$((sum + mod)) 
    		number=$((number / 10))    #divide num by 10.
	done 
	echo "Sum of digits of $temp is $sum" #Kept temp for not lossing original number
	
	#Read next number
	read -p "Enter a number: " number

done
